# 니케 캐릭터 채팅

Python 3.11 또는 3.12에서 실행하는 Streamlit 앱입니다.

## 실행

이 폴더에서 터미널을 열고 실행하세요.

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

1. 화면 왼쪽에서 OpenAI API 키를 입력하세요. 또는 `.env.example`을 `.env`로 복사하고 `OPENAI_API_KEY`를 설정하세요.
2. 캐릭터 엑셀을 업로드하거나 로컬 경로를 입력하세요.
3. 열 이름이 있는 행을 확인하세요. 기본값 2는 원래 코드의 `header=1`과 같습니다. 첫 번째 시트를 읽습니다.
4. **데이터 불러오기**를 누른 다음 질문하세요.

## 동작

- 질문과 답변은 현재 브라우저 세션에 유지됩니다. 새 대화 버튼으로 초기화합니다.
- ChromaDB는 기본적으로 앱 옆 `chroma_db` 폴더에 저장됩니다. 설정에서 기존 경로를 지정할 수 있습니다.
- 파일 내용과 헤더 행별 전용 컬렉션을 사용하며 기존 `my_collection`은 수정하지 않습니다. 같은 파일을 다시 불러오면 색인을 재사용합니다. 변경된 파일은 새 컬렉션에 등록되고 이전 색인은 보존됩니다.
- 원래 코드와 같이 Chroma 기본 임베딩을 사용합니다. 처음에는 모델 다운로드가 필요할 수 있습니다.
- 검색된 데이터와 최근 대화 최대 8개 메시지를 OpenAI에 전달해 `gpt-4o-mini`로 답변합니다. API 사용 요금이 발생할 수 있습니다.
- 검색 결과는 선택한 수만큼의 관련 문서이므로 전체 캐릭터 집계나 전체 목록을 보장하지 않습니다.
- 답변 아래에서 검색된 엑셀 행과 원문을 확인할 수 있습니다.
- 설정을 바꾼 후에는 데이터 불러오기를 다시 누르세요. 새 데이터가 성공적으로 연결되면 대화가 초기화됩니다.

참고: [Streamlit 채팅](https://docs.streamlit.io/develop/api-reference/chat), [OpenAI Responses 사용 예제](https://developers.openai.com/api/docs/quickstart), [Chroma 컬렉션](https://docs.trychroma.com/reference/python/collection).
