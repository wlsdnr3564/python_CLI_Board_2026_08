import os

import streamlit as st
from dotenv import load_dotenv
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

load_dotenv()

st.title("nikke 챗봇")

if "history" not in st.session_state:
    st.session_state.history = []

api_key = os.getenv("OPENAI_API_KEY") or os.getenv("openai_api_key")
if not api_key:
    st.warning("OPENAI_API_KEY가 설정되지 않았습니다. .env 또는 환경변수를 먼저 설정하세요.")
    st.stop()

uploaded_file = st.file_uploader("PDF 파일을 업로드하세요", type=["pdf"])

if uploaded_file is not None:
    st.write(f"업로드된 파일: {uploaded_file.name}")

    os.makedirs("temp", exist_ok=True)
    temp_file_path = os.path.join("temp", uploaded_file.name)
    with open(temp_file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    with st.spinner("PDF를 처리하는 중..."):
        pdf_loader = PyPDFLoader(temp_file_path)
        documents = pdf_loader.load()
        if not documents:
            st.warning("PDF에서 텍스트를 추출하지 못했습니다.")
        else:
            text_splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=50)
            split_docs = text_splitter.split_documents(documents)
            st.write(f"총 {len(split_docs)}개의 문서 조각이 생성되었습니다.")

            embeddings = OpenAIEmbeddings(model="text-embedding-3-large")
            vector_store = FAISS.from_documents(split_docs, embeddings)
            st.session_state.vector_store = vector_store
            st.success("문서 준비 완료")

if "vector_store" in st.session_state and "llm" not in st.session_state:
    st.session_state.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

if "vector_store" in st.session_state and "llm" in st.session_state:
    user_input = st.chat_input("질문을 입력하세요")

    if user_input:
        with st.spinner("질문을 처리하는 중..."):
            relevant_docs = st.session_state.vector_store.similarity_search(user_input, k=4)
            context = "\n\n".join(doc.page_content for doc in relevant_docs)
            prompt = (
                "다음 문맥을 바탕으로 질문에 답하세요.\n"
                "답변은 문맥에 근거해서 간결하게 작성하세요.\n\n"
                f"문맥:\n{context}\n\n질문:\n{user_input}\n\n답변:"
            )
            response = st.session_state.llm.invoke(prompt).content
            st.session_state.history.append((user_input, response))

for user_msg, bot_msg in st.session_state.history:
    with st.chat_message("user"):
        st.write(user_msg)
    with st.chat_message("assistant"):
        st.write(bot_msg)
