import chromadb
import re
from pathlib import Path

import pandas as pd

from openai import OpenAI
from dotenv import load_dotenv
import os


# PersistentClient 생성 및 저장 경로 지정
client = chromadb.PersistentClient(path=r"C:\Users\201\Documents\python_study\api\chroma_db")

xlsx_PATH = Path(r"C:\Users\201\Downloads\nikke_characters.xlsx")

# 컬렉션 생성 또는 불러오기
collection = client.get_or_create_collection(name="my_collection")

#excel 파일 읽기
df = pd.read_excel(xlsx_PATH, header=1)
# Unnamed 열 제거
mask = ~df.columns.astype(str).str.startswith("Unnamed:")
df = df.loc[:, mask]

# 각 캐릭터를 하나의 문서로 구성
records = []
# 각 행을 반복하면서 각 열의 값을 확인
for _, row in df.iterrows():
    parts = []
    # 각 열의 이름과 값을 확인
    for col_name, value in row.items():
        # 결측값이면 continue
        if pd.isna(value):
            continue
        # 문자열로 변환하고 공백 제거
        text = str(value).strip()

        # 특정 열 이름에 대한 처리
        if not text:
            continue
        # 다른 열 이름에 대해서는 기본 처리
        else:
            parts.append(f"{col_name}: {text}")

    # 각 행의 모든 열을 처리한 후, parts 리스트가 비어있지 않으면 records에 추가
    if parts:
        records.append("\n".join(parts))

# 데이터 추가하기
collection.add(
    documents=records,
    metadatas=[{"source": f"doc{i+1}"} for i in range(len(records))],
    ids=[f"id_{i}" for i in range(len(records))]
)

# API KEY 불러오기
load_dotenv()

openai_client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)

# 질문 입력
question = input("질문: ")

# ChromaDB에서 관련 데이터 검색
result = collection.query(
    query_texts=[question],
    n_results=3
)

# 검색 결과
documents = result["documents"][0]

# 검색 결과를 LLM에게 전달
context = "\n\n".join(documents)

response = openai_client.responses.create(
    model="gpt-4o-mini",
    input=f"""
다음은 승리의 여신:니케 캐릭터 데이터입니다.

{context}

위 데이터를 참고해서 다음 질문에 답해주세요.

질문: {question}

데이터에 없는 내용은 "문서에서 확인되지 않습니다"라고 답하세요.
"""
)

# 답변 
print(response.output_text)